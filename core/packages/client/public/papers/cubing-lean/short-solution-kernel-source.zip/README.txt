Compile main.tex with pdflatex (twice).
In anc/ run: bash cache.sh, then lake build CubeKernel,
lake env lean -DwarningAsError=true AuditPaper.lean, then
LEAN_NUM_THREADS=2 lake env leanchecker CubeDiameter CubeKernel
