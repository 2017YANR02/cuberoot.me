# Continuous Corners

以苹果公开 SwiftUI 路径为基准的 **TypeScript 连续圆角库**。几何核心、SVG/Canvas 输出、原生 DOM 与 React 适配共用同一套曲线。面向 Mira、CubeRoot 及后续项目，不依赖任何产品源码、数据库或服务。

当前版本 `0.3.0`，几何标准 `swiftui-27-uniform-v1`，另有 `swiftui-27-independent-v1`，支持独立四角及容器同心规则。578 组原生样本对照的最大控制点误差约为 0.0000283 个逻辑像素；macOS 与 iOS 模拟器的原始路径样本完全相同。**这是经数值核对的重建，不是苹果官方代码，也不承诺逐位/逐像素相同。** 精度、参数边界和原生依据见 [几何说明](docs/geometry.md)。

## 安装与构建

本阶段提供本地包，尚未发布 npm。开发工具需要 Node 24+，运行时核心无第三方依赖、无 Mac 依赖；React 是可选 peer dependency。

```sh
npm ci
npm run check
mkdir -p output
npm pack --pack-destination output
# 在使用方项目中安装上一步生成的 .tgz；不要跨仓库 import 源文件
npm install /path/to/2017yanr02-continuous-corners-0.3.0.tgz
```

后续发布时按版本锁定；不能将本机绝对路径导入当作正式共享包接入。仓库当前私有，未授权公开发布。

## 几何核心与 Canvas

```ts
import { continuousCorners, tracePath } from "@2017yanr02/continuous-corners";

const path = continuousCorners({ width: 320, height: 200, radius: 24 });
// SVG: <svg viewBox="0 0 320 200"><path d={path.d} /></svg>
// 画布先按宿主的 DPR 配置逻辑坐标，再绘制：
context.beginPath();
tracePath(context, path.commands);
context.fill();
```

返回 `d`、`commands`、`effectiveRadius` 和几何 `version`。宽高改变后重新计算，不非等比拉伸旧路径。圆形头像保持真正的圆形，不使用本矩形算法。

## 容器与独立四角

```ts
import { resolveCornerRadii, continuousCornerRadii } from "@2017yanr02/continuous-corners";
const frame = { x: 8, y: 16, width: 100, height: 100 };
const container = { x: 0, y: 0, width: 300, height: 200, radii: [48, 48, 48, 48] as const };
const corner = { concentric: true, minimum: 12 } as const;
const radii = resolveCornerRadii(frame, [corner, corner, corner, corner], container);
// [32, 12, 12, 12]，物理顺序：左上、右上、右下、左下
const nested = continuousCornerRadii({ ...frame, radii });
```

原生 iOS 27 容器查询、规则、误差来源、最新 Apple/WWDC/WebKit 资料及复现见 [2026 体系核对](docs/apple-system-2026.md)。网页声明 `data-corner-container` 或传入已有容器选择器；后代沿用 CSS 半径作为最小值，`data-corner-style="fixed"` 可固定，`data-corner-uniform="top"` 可统一上方两角。缺少容器时保留原样，不猜测硬件屏幕圆角。

## 原生网页

```ts
import { attachSurface } from "@2017yanr02/continuous-corners/dom";

const surface = attachSurface(document.querySelector<HTMLElement>(".card")!, {
  radius: 24,
  fill: "var(--card-background, white)",
  borderColor: "var(--card-border, #d2d2d7)",
  borderWidth: 1,
  shadow: "0 4px 10px #0002",
});
surface.update({ radius: 20 });
// 离开页面/卸载时：surface.destroy();
```

宿主须有尺寸且能包含子节点。ResizeObserver 自动处理尺寸变化；真实按钮可以直接绑定，input/select/textarea/img 等使用外层容器。SVG 层不替代输入控件，不裁切整棵子树。背景、边框和阴影通过参数传入，不要与宿主 CSS 重复控制同一效果。

## React

```tsx
import { Surface } from "@2017yanr02/continuous-corners/react";

<Surface corners={{ radius: 24, fill: "white", borderColor: "#ddd", borderWidth: 1 }}
  style={{ padding: 24 }}>
  <h2>资料</h2>
  <input aria-label="昵称" />
</Surface>
```

`Surface` 保留原生内容语义，支持 StrictMode、参数更新和卸载。它本身是 div，不伪造按钮语义；SSR 输出内容，hydration 后附加绘制层。需要首帧精准几何时使用已知尺寸 SVG，详见 [平台接入说明](docs/platforms.md)。

## 已有网站迁移

```tsx
import { SiteCorners } from "@2017yanr02/continuous-corners/react";
// 根布局挂载一次；多个共享宿主挂载会共用一个订阅。
<SiteCorners exclude=".third-party-widget" containers=".card-surface" />
```

非 React 网页使用 `installSiteCorners(root)`（`/site` 入口），卸载时调用 `destroy()`。读取已有 CSS 像素四角半径，通过 SVG border-image 绘制背景和边框，不替换表单、插入子节点或裁切弹层；尺寸、主题、路由节点变化会更新。

适配纯色与单层、普通色标的线性渐变。圆形、椭圆半径、虚线/不同宽度边框、多层或径向背景、带背景箭头的原生选择框、第三方画布和伪元素保留原生样式。原生阴影和焦点轮廓也保留；需要这些效果同路径时，显式使用 `Surface`。这是一项渐进迁移能力，不能宣称每个已有视觉效果都已经完全转成苹果路径。

## Safari 与其他平台

网页使用标准 SVG，不依赖 CSS `corner-shape`；支持该 CSS 的浏览器也不会切换另一套曲线。Safari 验证按版本和范围记在 [跟踪文档](docs/tracker.md)；不能把共享库检查当作所有产品与旧浏览器验收。

Canvas 适配只依赖通用绘图方法，可由小程序画布消费；其他原生平台使用同一 SVG `d` 或 M/L/C/Q/Z 命令。平台控件和打包适配不是自动完成的，Android/Flutter/正式微信客户端尚未验收。具体约定见 [平台接入说明](docs/platforms.md)。

## 开发与原生对照

```sh
npm run typecheck
npm test
npm run build
npm run demo                 # output/demo.html，离线可打开
npm run inspect              # 原生样本 SVG 画廊
# 以下原生导出/引擎检查需要 Mac + Xcode：
npm run verify:apple
node tools/verify-webkit.ts   # 先执行 npm run demo
node tools/verify-webkit.ts <已启动的iOS模拟器ID>
xcrun swift tools/export.swift 320 200 24 > output/native.json
```

Python 工具已移除。Swift 仅用于调用苹果公开接口导出校验基准，以及可选的隔离 WebKit 检查；不进入运行时安装包。默认检查使用已保存的原生数据，Linux/Windows 上也可执行。

完整任务状态、验收缺口与发布边界见 [跟踪文档](docs/tracker.md)。Mira 与 CubeRoot 使用相同的版本化本地安装包；未 Push、发布 npm 或部署。
