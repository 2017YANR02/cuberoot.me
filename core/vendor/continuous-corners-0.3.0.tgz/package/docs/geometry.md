# 当前范围说明（0.3.0）

统一半径仍用下文基线；独立四角、容器同心查询、最小值、角组和 iOS 27 新 API 的完整研究见 [Apple 2026 圆角体系](apple-system-2026.md)。新增 262 条独立路径与 360 个矩形容器查询已有原生对照；运行时不调用 SwiftUI，也不把 CSS squircle 当作等价曲线。

# 几何依据与精度

当前几何版本为 `swiftui-27-uniform-v1`。它重建了苹果公开 SwiftUI `RoundedRectangle(..., style: .continuous).path(in:).cgPath` 的**四角相同半径**输出，不是苹果闭源实现的源码移植，也不是 Figma 平滑度或通用超椭圆。

## 规则

名义半径先限制在宽高较短边的一半。每角由三段三次贝塞尔组成，中间段使用原生导出的固定归一化控制点；邻接直边的两段按各轴可用空间调整。角部最大占用约为名义半径的 1.528665 倍；空间不足时缩短过渡段，而不是拉伸整条路径。

核心先计算归一化控制点，再乘半径并对称映射四角。保留 Float32 系数与中间舍入，用于接近苹果返回的浮点控制点；转成 SVG 时不再次截断小数。四角半径为零时输出矩形。返回 `effectiveRadius`，调用方可以查看被限制后的半径。

## 原生对照

`fixtures/macos-27.0.1.json` 为十组初始原始导出；`fixtures/apple-matrix.json` 为 578 组独立原生输出，含固定种子的 512 组分数尺寸与 66 组边界样本。宽高、半径和原始命令均保留，常规 Node 测试直接比较这些数据，不以 TypeScript 实现生成自己的期望值。

`fixtures/ios-comparison.json` 记录 iOS 27.0 模拟器与 macOS 27.0.1 的 578 组所有样本字段完全相同。它不等于真机渲染对照，也不证明其他系统版本或 UIKit/CALayer 等同于 SwiftUI 的路径 API。

TypeScript 与这批原生输出比较了 46,582 个坐标，其中 981 个有非零浮点差异；最大绝对误差为 **0.00002828969809343107** 个逻辑坐标单位。误差阈值为 `effectiveRadius × 2.4e-7 + max(width, height) × Number.EPSILON × 4`，涵盖归一化 Float32 舍入与最终 Float64 映射。报告见 `fixtures/verification.json`。

所以当前承诺是**已记录范围内的数值等价**，不能宣传为任意参数逐位相同、苹果官方算法或跨设备逐像素相同。若固定尺寸必须逐控制点一致，直接使用 Swift 导出的 `svgPath` / `commands`；不要经过重建算法，也不要非等比拉伸。

## 参数与限制

- 宽、高须有限且大于零，半径须有限且不小于零；最大输入坐标为 10,000,000。业务应使用合理的 CSS/绘制逻辑单位。该输入上限不代表整个数值域已经穷举验证。
- 目前只支持统一半径，不接受独立四角半径或椭圆半径；不能静默替代这些形状。
- 路径不包含背景、阴影、抗锯齿、缩放、触控区域或系统布局。不同渲染器可能在相同几何边界产生不同抗锯齿像素。
- 将动态尺寸输入核心重新计算，不使用 `preserveAspectRatio="none"` 来拉伸一个固定样本。
- 圆形头像、单选框、进度点属于圆形语义，保持各平台真正的圆形；不把它们变成连续圆角矩形。

## 更新原生基准

在 Mac 上执行 `npm run verify:apple`。工具把新结果写入 `output/`，不会覆盖已有基线。检查系统版本、拓扑与误差后再人工保留新版本。独立 iOS 运行可按跟踪文档中的复现命令执行；用户设备标识不写入仓库。

## 公开算法调查（2026-10-19）

公开实现确实存在，不能说“网上没有苹果风格的算法”。关键是区分目标 API、系统版本与精度。

- [PaintCode 的 iOS 7 路径研究与源码](https://www.paintcodeapp.com/news/code-for-ios-7-rounded-rectangles)：通过公开 CGPath 元素读取逆向 UIKit，公开普通版和包含旧 UIKit 异常行为的兼容版。它是有价值的前例，但旧系统的拓扑与半径约束不能直接当作现代 SwiftUI 的实现。
- [Flutter RoundedSuperellipseBorder](https://api.flutter.dev/flutter/painting/RoundedSuperellipseBorder-class.html)：官方开源实现明确以模仿 iOS 风格为目的。其 [引擎源码](https://github.com/flutter/flutter/blob/master/engine/src/flutter/impeller/geometry/round_superellipse_param.cc) 使用超椭圆参数表和圆弧，不能据此宣称等于当前 SwiftUI 每个控制点。
- [ContinuousCornerKit](https://github.com/tsuijunxi/ContinuousCornerKit) 与 [作者推导](https://tsuijunxi.github.io/en/2026/06/23/the-art-of-continuous-corners/)：从曲率过渡和截图拟合参数，公开说明是重建；与原始路径导出不是同一种证据。
- [苹果公开专利 US9396565B2](https://patents.google.com/patent/US9396565B2/en)：解释图形边界渲染设计，但不是某版 SwiftUI 的可直接移植、逐位等同实现。本记录不作许可或法律判断。
- [figma-squircle](https://github.com/phamfoo/figma-squircle) 的目标是 Figma 曲线。苹果风格、Figma 平滑圆角和数学超椭圆不能混称同一个算法。

因此本库保留从公开 Apple API 导出的原始命令作为裁判，并用 TypeScript 重建动态尺寸。数值差异集中在 Float32 系数及紧凑尺寸插值；浮点运算顺序是可能原因，但尚未证明苹果内部每一步实现，不能说已经消除了误差。直接离线导出固定尺寸可以消除“重建控制点”误差；屏幕抗锯齿仍取决于渲染器。
