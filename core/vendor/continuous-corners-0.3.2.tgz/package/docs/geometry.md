# 当前范围说明（0.3.0）

统一半径仍用下文基线；独立四角、容器同心查询、最小值、角组和 iOS 27 新 API 的完整研究见 [Apple 2026 圆角体系](apple-system-2026.md)。新增 262 条独立路径与 360 个矩形容器查询已有原生对照；运行时不调用 SwiftUI，也不把 CSS squircle 当作等价曲线。

# 几何依据与精度

当前几何版本为 `swiftui-27-uniform-v1`。它重建了苹果公开 SwiftUI `RoundedRectangle(..., style: .continuous).path(in:).cgPath` 的**四角相同半径**输出，不是苹果闭源实现的源码移植，也不是 Figma 平滑度或通用超椭圆。

## 规则

名义半径先限制在宽高较短边的一半。每角由三段三次贝塞尔组成，中间段使用原生导出的固定归一化控制点；邻接直边的两段按各轴可用空间调整。角部最大占用约为名义半径的 1.528665 倍；空间不足时缩短过渡段，而不是拉伸整条路径。

核心先计算归一化控制点，再乘半径并对称映射四角。保留 Float32 系数与中间舍入，用于接近苹果返回的浮点控制点；转成 SVG 时不再次截断小数。四角半径为零时输出矩形。返回 `effectiveRadius`，调用方可以查看被限制后的半径。

## 原生对照

`fixtures/macos-27.0.1.json` 为十组初始原始导出；`fixtures/apple-matrix.json` 为 578 组独立原生输出，含固定种子的 512 组分数尺寸与 66 组边界样本。宽高、半径和原始命令均保留，常规 Node 测试直接比较这些数据，不以 TypeScript 实现生成自己的期望值。

`fixtures/ios-comparison.json` 记录 iOS 27.0 模拟器与 macOS 27.0.1 的 578 组所有样本字段完全相同。它不等于真机渲染对照，也不证明其他系统版本或 UIKit/CALayer 等同于 SwiftUI 的路径 API。

TypeScript 与这批原生输出比较了 46,582 个坐标，其中 981 个有非零浮点差异；最大绝对误差为 **0.00002828969809343107** 个逻辑坐标单位。误差阈值为 `effectiveRadius × 2.4e-7 + max(width, height) × Number.EPSILON × 4`，涵盖归一化 Float32 舍入与最终 Float64 映射。报告见 `fixtures/verification.json`。

所以当前承诺是**已记录范围内的数值等价**，不能宣传为任意参数逐位相同、苹果官方算法或跨设备逐像素相同。若固定尺寸必须逐控制点一致，直接使用 Swift 导出的 `svgPath` / `commands`；不要经过重建算法，也不要非等比拉伸。

## 参数与限制

- 宽、高须有限且大于零，半径须有限且不小于零；最大输入坐标为 10,000,000。业务应使用合理的 CSS/绘制逻辑单位。该输入上限不代表整个数值域已经穷举验证。
- 本节的 continuousCorners API 处理统一半径；0.3.0 的 continuousCornerRadii 另支持独立四角。椭圆半径尚不支持。
- 路径不包含背景、阴影、抗锯齿、缩放、触控区域或系统布局。不同渲染器可能在相同几何边界产生不同抗锯齿像素。
- 将动态尺寸输入核心重新计算，不使用 `preserveAspectRatio="none"` 来拉伸一个固定样本。
- 圆形头像、单选框、进度点属于圆形语义，保持各平台真正的圆形；不把它们变成连续圆角矩形。

## 更新原生基准

在 Mac 上执行 `npm run verify:apple`。工具把新结果写入 `output/`，不会覆盖已有基线。检查系统版本、拓扑与误差后再人工保留新版本。独立 iOS 运行可按跟踪文档中的复现命令执行；用户设备标识不写入仓库。

## 公开算法调查（2026-10-19）

公开实现确实存在，不能说“网上没有苹果风格的算法”。关键是区分目标 API、系统版本与精度。

- [PaintCode 的 iOS 7 路径研究与源码](https://www.paintcodeapp.com/news/code-for-ios-7-rounded-rectangles)：通过公开 CGPath 元素读取逆向 UIKit，公开普通版和包含旧 UIKit 异常行为的兼容版。它是有价值的前例，但旧系统的拓扑与半径约束不能直接当作现代 SwiftUI 的实现。
- [Flutter RoundedSuperellipseBorder](https://api.flutter.dev/flutter/painting/RoundedSuperellipseBorder-class.html)：官方开源实现明确以模仿 iOS 风格为目的。其 [引擎源码](https://github.com/flutter/flutter/blob/master/engine/src/flutter/impeller/geometry/round_superellipse_param.cc) 使用超椭圆参数表和圆弧，不能据此宣称等于当前 SwiftUI 每个控制点。
- [ContinuousCornerKit](https://github.com/tsuijunxi/ContinuousCornerKit) 与 [作者推导](https://tsuijunxi.github.io/en/2026/06/23/the-art-of-continuous-corners/)：从曲率过渡和截图拟合参数，公开说明是重建；与原始路径导出不是同一种证据。
- [苹果公开专利 US9396565B2](https://patents.google.com/patent/US9396565B2/en)：解释图形边界渲染设计，但不是某版 SwiftUI 的可直接移植、逐位等同实现。本记录不作许可或法律判断。
- [figma-squircle](https://github.com/phamfoo/figma-squircle) 的目标是 Figma 曲线。苹果风格、Figma 平滑圆角和数学超椭圆不能混称同一个算法。

因此本库保留从公开 Apple API 导出的原始命令作为裁判，并用 TypeScript 重建动态尺寸。数值差异集中在 Float32 系数及紧凑尺寸插值；浮点运算顺序是可能原因，但尚未证明苹果内部每一步实现，不能说已经消除了误差。直接离线导出固定尺寸可以消除“重建控制点”误差；屏幕抗锯齿仍取决于渲染器。

## 2026-10-19：严格数学连续性核查

应区分 Apple API 的 `.continuous` 命名、原生导出路径一致性与微分几何意义的 G² 连续。此前仅逐控制点核对，不能据此承诺严格曲率连续。

三次贝塞尔 B(t) 的端点导数为 B′(0)=3(P1−P0)、B′(1)=3(P3−P2)，二阶导数为 B″(0)=6(P2−2P1+P0)、B″(1)=6(P3−2P2+P1)。正则曲线的带符号曲率为 det(B′,B″)/|B′|³。G¹ 要求左右切线同向，G² 还要求左右带符号曲率相同；它们不同于要求参数速度也相等的 C¹/C²。

本次重新调用公开 SwiftUI 接口导出 320×200、r=24 的原生路径。左上第一段结束与第二段开始的切线方向分别为 −72.45315512787127°、−69.99991480020154°，差约 2.4532403276697323°；左右曲率分别约 0.029852949994039778 和 0.04464429529720789。这是分段曲率的单侧极限；接点本身不具有单一光滑曲率。该公开 CGPath 样本甚至不是严格 G¹，因此不能称为处处 G²。直线接第一段的位置曲率为 0，局部过渡与内部接点必须分开讨论。

证据见 fixtures/continuity-audit-macos-27.0.1.json；可用 tools/export.swift 320 200 24 重新导出，并对左上三个 C 命令的控制点代入上述端点公式。此结果针对该系统的公开 CGPath，不推断屏幕上所有原生控件如何渲染，也不将差异归因于 TypeScript 浮点误差。要构造严格 G² 曲线，需要额外约束、重新求控制点；那将改变本库当前“忠于公开原生路径”的目标，故未自动改算法。

## 2026-10-19：原生直接绘制与公开路径绘制并不等价

针对负责人的质疑，新增 tools/compare-native-render.swift：在同一个 SwiftUI ImageRenderer 中分别绘制 RoundedRectangle 和其公开 CGPath 构造的 Path，使用相同 frame、padding、颜色及 scale。普通 circular 样式作为对照，避免把不一致直接归因于整体坐标或背景。

100×100、r24 的样本在 scale=3/12/24 时，circular 两种绘制的 RGBA 通道逐项相同；continuous 均不相同。在左侧角部选定扫描行，按 50% RGB 通道值线性插值估计边界，最大横向差分别约为 0.1850、0.1660、0.1549 个逻辑单位。这个量是选定扫描行上的栅格边界估计，不是完整轮廓 Hausdorff 距离，不是全部尺寸的误差上限，也不能据此证明原生内部曲率连续。

证据见 fixtures/native-render-comparison-macos-27.0.1.json。该对照支持公开 CGPath 不足以作为原生 RoundedRectangle 最终绘制的完整基准。此前 0.0000283/0.0000708 是 TypeScript 与公开导出控制点的差异，不能宣传为与原生最终轮廓的总误差。也不能把公开路径内部接点的不连续推广到原生直接绘制。负责人要求与苹果原生尽量一致，当前实现尚未证明达到；后续必须以原生直接绘制补充验证，不能仅继续收紧导出路径的浮点误差。

复现：xcrun swift tools/compare-native-render.swift。仅依赖公开 SwiftUI/ImageRenderer/Core Graphics 接口；不使用截图拟合结果替换当前运行时，不改变或覆盖旧原生基线。本次只在 macOS 27.0.1 验证，iPhone Safari 延后安排保持。
