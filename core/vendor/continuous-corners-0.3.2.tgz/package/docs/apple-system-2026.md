# 苹果 2026 圆角体系核对与跨平台契约

2026-10-19 核对。目标是采用 Apple SwiftUI 27 的公开输出与容器规则作为版本化基准，不以“像苹果”代替数值证据。运行时全为 TypeScript；Swift 只在维护时生成独立基线。

## 本次修正

此前只处理统一半径的连续路径，遗漏了容器关系。这不是完整的 Apple 圆角系统。0.3.0 增加四角独立路径、容器查询、最小半径、角组统一、方向映射和网页嵌套更新。

时间线也必须区分：`ConcentricRectangle` 和 UIKit 圆角配置始于 26 系列；27 系列新增 GeometryProxy 半径查询，并扩展 AppKit 圆角配置。本机 Xcode 27 的公开 Swift 接口与在线文档均已核对，不把所有能力都误写成 2026 新增。

## 官方来源与用途

| 来源 | 已核对的作用 |
| --- | --- |
| [iOS 27 发布说明](https://developer.apple.com/documentation/ios-ipados-release-notes/ios-ipados-27-release-notes) | 列出 GeometryProxy 两个新的同心半径查询接口 |
| [GeometryProxy.concentricCornerRadii](https://developer.apple.com/documentation/swiftui/geometryproxy/concentriccornerradii) | 返回视图范围内相对容器的四角半径，可用于自定义绘制与动画；本身不绘图 |
| [concentricCornerRadii(in:)](https://developer.apple.com/documentation/swiftui/geometryproxy/concentriccornerradii(in:)) | 查询局部坐标中的指定矩形；用于本仓库独立原生数值基线 |
| [ConcentricRectangle](https://developer.apple.com/documentation/swiftui/concentricrectangle) | 每角固定、同心、最小半径、直角，以及统一角组；组内先求值后取最大 |
| [containerShape](https://developer.apple.com/documentation/swiftui/view/containershape(_:)) | 声明供后代使用的容器形状；系统 sheet/popover 可自动提供 |
| [RectangleCornerRadii](https://developer.apple.com/documentation/swiftui/rectanglecornerradii) | 语义四角数值载体，leading/trailing 必须在布局方向边界映射 |
| [Edge.Corner.Style](https://developer.apple.com/documentation/swiftui/edge/corner/style) | fixed、concentric 与 minimum 的语义 |
| [RoundedRectangularShapeCorners](https://developer.apple.com/documentation/swiftui/roundedrectangularshapecorners) | 新的四角配置表达，不是可独立复制的曲线源码 |
| [containerCornerInsets](https://developer.apple.com/documentation/swiftui/geometryproxy/containercornerinsets) | 避让屏幕边缘或窗口控件的几何信息；不能直接当圆角半径 |
| [UICornerConfiguration](https://developer.apple.com/documentation/uikit/uicornerconfiguration-swift.struct) | UIKit 独立/统一角、胶囊与容器同心配置 |
| [UIView.effectiveRadius](https://developer.apple.com/documentation/uikit/uiview/effectiveradius(corner:)) | 读取 UIKit 已解析半径；多个角返回最大值，不是路径导出 |
| [NSView.cornerConfiguration](https://developer.apple.com/documentation/appkit/nsview/cornerconfiguration) | AppKit 配置、失效更新和有效半径 |
| [WWDC26 Modernize your AppKit app](https://developer.apple.com/videos/play/wwdc2026/289/) | 15:41 起演示容器同心、minimum 与 uniformCorners |
| [WWDC26 What’s new in SwiftUI](https://developer.apple.com/videos/play/wwdc2026/269/) | 新平台响应式布局和框架能力背景，不能代替具体几何接口文档 |
| [WWDC26 Modernize your UIKit app](https://developer.apple.com/videos/play/wwdc2026/278/) | iPhone 可调整窗口尺寸；不应按机型硬编码角半径 |
| [WWDC25 Build a SwiftUI app with the new design](https://developer.apple.com/videos/play/wwdc2025/323/) | 既有同心圆角设计体系的来源 |
| [Path.cgPath](https://developer.apple.com/documentation/swiftui/path/cgpath) | 直接读取 SwiftUI 输出；再由 CGPath 的公开遍历接口导出控制点 |
| [WebKit TP 252](https://webkit.org/blog/18304/release-notes-for-safari-technology-preview-252/) / [254](https://webkit.org/blog/18420/release-notes-for-safari-technology-preview-254/) | CSS corner-shape、阴影/outline/裁切仍有实现演进；TP 修复不能推定稳定 Safari 已发布 |
| [WebKit corner-shape 实现记录](https://results.webkit.org/commit?id=315044%40main&repository_id=webkit) | CSS squircle 是标准 superellipse 参数体系，不能当作 SwiftUI 路径的同义词 |

用户提供的 ChatGPT 分享在本次浏览器仅显示页面外壳，无正文，不能列为已读或独立权威证据。上表与本机公开 API 构成实际依据。第三方公开算法、PaintCode、Flutter 和 Figma 的比较另见 geometry.md。

## 分成三个明确层次

1. **容器与布局**：声明容器矩形和有效四角半径，按子视图实际位置计算。每个视图可以是固定半径，也可以同心并带最小值。避免把每个 DOM 祖先都猜成容器。
2. **曲线几何**：将解析后的四角半径转换为 SwiftUI 27 风格的连续路径。紧凑尺寸要处理邻角相遇，不能只把一条固定 SVG 拉伸。
3. **绘制**：SVG、Canvas、DOM 与 React 共用上述结果。浏览器不会直接调用 UIKit/SwiftUI；Safari 同样使用这份几何。原生 SwiftUI/UIKit/AppKit 项目仍优先调用系统公开接口。

### 经原生验证的矩形容器规则

物理四角顺序为左上、右上、右下、左下。以左上角为例：

```
gap = max(child.left - container.left, child.top - container.top)
r = clamp(container.topLeftRadius - gap, 0, min(child.width, child.height) / 2)
```

其余角用对应两条边的带符号距离。外扩矩形允许负 gap。**max 两条边距离是本次原生实验结果，不是把文档“distance”擅自解释为欧氏距离。** 矩形容器基线共 360 个查询（含不等 inset、非居中、小尺寸、外扩、不同容器半径）逐数值相等。原生宿主在没有显式 containerShape 时仍可提供默认方形根容器；网页没有这些窗口信息，所以缺少显式容器时返回 null，由 fixed/minimum 决定后备行为。

组内统一规则在求各角候选值后取最大，再进行尺寸约束。四角碰撞按原生路径输出先约束横向邻角，再约束纵向邻角；小半径优先保留。传统 CSS 全体同比缩小的约束不能直接替用。

### 曲线路径与误差

每角使用三段三次贝塞尔，另有直线边。控制点来自苹果公开 Path 输出；过渡长度根据邻角可用边长压缩。固定原生输出直接序列化为 SVG 时不需要拟合。

动态网页无法对每个实时宽高调用 SwiftUI，因此 TypeScript 重建这些运算。578 组统一半径样本最大控制点差约 0.0000283；新增 262 组独立四角最大差约 0.0000708 个逻辑单位。原因包括原生 Float32 中间值、Float64 坐标和运算顺序；这不是逐位相同的证明，也不声称所有尚未采样输入都只有该误差。所有基线参数及各坐标可复查，测试按明示容差逐项比较。最终抗锯齿与屏幕像素又是另一层，不能用几何通过冒充逐像素一致。

macOS 27.0.1 与 iOS 27.0 模拟器对这 262 条路径及 450 条查询（含默认宿主容器）输出一致。证据见 `fixtures/apple-system-macos-27.0.1.json` 与 `fixtures/system-ios-comparison.json`。这是 SwiftUI 基准，不证明 UIKit 所有控件、Liquid Glass 或硬件屏幕轮廓全部相同。

## 产品采用规则

- 已有 CSS 的固定半径作为最小半径，保留组件原有层次。显式产品卡片选择器或 `data-corner-container` 建立容器。
- 子组件可用 `data-corner-style="fixed"` 保持固定；`data-corner-minimum="12"` 指定最小值；`data-corner-uniform="top"` 等设置角组。
- CSS 物理四角支持不同像素半径；百分比/椭圆保持原生。圆形头像和旋钮保持真正圆形。
- 位移、窗口大小、滚动、主题和 DOM 变化会重新计算。旋转/缩放祖先的同心解析跳过，避免轴对齐包围盒造成错误；固定路径仍按布局尺寸绘制。
- Web 无公开等价接口读取 iPhone 屏幕硬件四角，不能将 safe-area inset 当半径或建立机型猜测表。以页面显式容器为准。
- 可变宽高、混合边框、复杂背景、伪元素以及宿主原生阴影需要各自绘制适配；当前支持范围与保留 CSS 情况详见 platforms.md，不宣称全站所有视觉效果都已转换。

## 重现与后续 OS 维护

`node tools/system-cases.ts` 生成固定种子输入；`xcrun swift tools/export-system.swift output/system-input.json` 导出本机结果。iOS 模拟器以 `-target arm64-apple-ios27.0-simulator` 编译同一工具，在已启动的模拟器中执行同一输入。原始证据留在 fixtures，新系统结果先写 output，比对后再决定是否新增几何版本，不能静默覆盖旧基线。

新增 API 在纯 TypeScript 的 `src/index.ts`：`fitCornerRadii`、`concentricCornerRadii`、`resolveCornerRadii`、`physicalCornerRadii`、`continuousCornerRadii`。原统一半径 API 保持兼容。运行时不依赖 Mac、Apple 服务、私有 API 或产品仓库。
