# 各平台接入约定

所有适配层使用同一个 `continuousCorners({ width, height, radius })`，得到 SVG `d` 与通用 `commands`。不要在某个浏览器中改用 CSS squircle、Figma 平滑度或系统默认 border-radius，否则曲线标准会分叉。所有项目固定同一个包版本及几何版本。

## 网页与 Safari

原生 DOM 使用 `attachSurface`；React 使用 `Surface`。Vue/Svelte 等框架在挂载时调用 `attachSurface`、参数改变时调用 `update`、卸载时调用 `destroy`，不需要引入 React。

适配层用独立 SVG 绘制背景、内侧边框和焦点环。`ResizeObserver` 按实际 CSS 宽高重算路径，支持分数尺寸与元素缩放。不会裁切所有子节点，不会替换表单控件，不会扫描全站 DOM（这是显式 Surface 的行为；SiteCorners 另见下文）。内部 SVG 忽略鼠标和辅助技术，真实控件继续接收输入。

宿主需要有尺寸且能包含子节点，建议使用 block、inline-block、flex 或 grid，不能是 `display:contents`、普通行内文本节点或 replaced element。宿主背景、border-width、box-shadow、isolation，以及原先 static 的 position 由适配层管理；卸载时恢复仍由它持有的样式。通过 `fill`、`borderColor`、`borderWidth`、`shadow` 修改表面，不在挂载期间同时写这些 CSS 属性。

`fill` 使用 SVG paint（颜色、CSS颜色变量或已有 SVG paint server 的 URL），不直接接受 CSS linear-gradient/background-image。含复杂背景的产品组件需要专门接入，不应全站自动扫描替换。额外 stacking context 也需要由应用为弹层安排层级或 portal。

输入框、图片、视频、Canvas、select、textarea 使用外层表面容器；不要直接 attach。图片若需按轮廓裁切，必须单独给图片层设置同尺寸路径，不能裁切含弹层和焦点环的整个外层。滚动区域同样置于表面容器内部。原生 select 的系统弹出菜单不由本库接管。

焦点环支持 `:focus-visible`，不要额外移除后备原生焦点样式，除非应用明确提供了可见替代。宿主若设置 overflow:hidden，仍会剪掉外部阴影/焦点环，这是调用方布局约束。带 `<base href>` 的页面在客户端路由更新后调用 `refresh()` 更新 SVG 引用。

React 的 `Surface` 是 div 容器，不伪造 button/input 语义。原生按钮可以用 DOM 适配器直接绑定；React 可通过 ref 在 effect 中绑定真实 button。SSR 只渲染语义内容，SVG 在 hydration 后附加；需要首帧精确轮廓的页面应提供已知尺寸的服务端 SVG，不能把无 JS 时的外观当作已增强状态。

已执行 macOS 与 iOS 模拟器的 WKWebView 数值/生命周期检查。Safari 真机与产品页面的本次结果见 tracker.md；未覆盖所有旧版本 Safari，不把引擎检查描述为全设备视觉通过。

## Canvas 与微信小程序

使用 `tracePath(context, path.commands)`，它只要求 moveTo、lineTo、bezierCurveTo、quadraticCurveTo、closePath，不依赖 DOM 或 Path2D。调用方负责 beginPath、fill/stroke、DPR 与画布大小。小程序打包时编译 TypeScript 或使用 dist 的 JavaScript 核心；不能导入 DOM/React 入口。

Canvas 只负责绘制，不能替代可访问的输入框、按钮和菜单。小程序的原生控件、触控和滚动由平台组件负责；表面背景可以单独绘制。这个接入契约已用通用绘制接口检查，尚未接入正式微信客户端。

## 原生 App 与其他运行时

React Native 或其他支持 SVG path 的运行时可把 `d` 交给自己的 SVG 渲染器；Android、Flutter 等宿主可以消费相同 M/L/C/Q/Z 命令或 SVG 数据。宿主负责将 CSS/逻辑尺寸映射为本平台逻辑坐标，避免把物理像素作为另一套半径输入。本仓库当前不提供 Android/Flutter 的编译插件或已验收原生控件。

苹果原生 UI 若以系统当前风格为优先，可使用 `.continuous`；但系统升级后未必与固定版本的网页基线相同。若要求跨平台固定几何，则原生端也绘制相同版本的路径。路径由本库供给或离线导出，生产端不需要连接 Mac。

## 产品迁移

Mira 根布局、CubeRoot Web 根布局和共享 app-ui 宿主安装 `SiteCorners`，两个仓库固定同一个 `0.3.0` tarball；本地包随产品 Git 提交，不依赖开发者机器路径或远程未发布源码。未来更新时统一更换包和锁文件，禁止只复制某个函数。

`SiteCorners` 增量观察CSS 像素四角半径，将纯色/普通单层线性渐变和统一实线边框绘入 SVG border-image。它不向已有组件插入子节点，避免破坏 React 延迟 hydration；也不改变控件内容、尺寸、交互和子级 overflow。图片用独立路径裁切。卸载删除独立构造样式表，保留调用方样式。

限制：圆形和百分比/独立四角/椭圆半径、虚线和不统一边框、自定义 border-image、复杂/多层背景、背景含图标的原生输入控件、伪元素仍由原 CSS 绘制。阴影、outline、backdrop-filter 也未转换到本路径。`data-corner-shape="native"` 可排除组件及其子树；不要为覆盖率强行破坏第三方控件。复杂组件逐一使用显式 Surface 接入，并独立检查层级。

SiteCorners 在 hydration 后增强，SSR/无 JS 仍为普通圆角；动态 CSS 过渡仅更新起止状态，未承诺逐帧重建。共享 app-ui 接入代表薄宿主复用相同代码，不等于已打包或在 Android/Harmony/桌面/微信原生控件上验收。Canvas 与 SVG 核心已可复用；各平台控件需各自适配。

公开发布、npm 发布及产品部署另按当批授权执行。本批只有本地提交。


0.3.0 增加独立四角和显式容器规则，详见 [2026 Apple 体系](apple-system-2026.md)。容器靠产品选择器或 data-corner-container 声明；CSS 半径默认作为 minimum，固定覆盖用 data-corner-style。需要独立阴影/焦点环的显式 Surface 也可传 radii 四元组。带旋转/缩放祖先时不猜测同心关系。
